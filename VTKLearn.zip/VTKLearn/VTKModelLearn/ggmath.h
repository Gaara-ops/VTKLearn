#ifndef GGMATH_H
#define GGMATH_H

class GGMath
{
public:
    GGMath();
};

#endif // GGMATH_H
