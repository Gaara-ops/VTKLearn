#include "ggmath.h"

GGMath::GGMath()
{
}
