#ifndef GLOBEINCLUDE_H
#define GLOBEINCLUDE_H


//glew
#include <GL/glew.h>
//freeglut
#include <GL/freeglut.h>

//other
#include <array>
#include <QDebug>
#include <iostream>
#include <fstream>
#include <sstream>

#endif // GLOBEINCLUDE_H
