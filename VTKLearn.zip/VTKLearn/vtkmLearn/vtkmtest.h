#ifndef VTKMTEST_H
#define VTKMTEST_H


class VTKMTest
{
public:
    VTKMTest();
    void CreateVTKMTest();
};

#endif // VTKMTEST_H
