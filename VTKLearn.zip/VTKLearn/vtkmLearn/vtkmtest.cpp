#include "vtkmtest.h"
#include "GlobeInclude.h"

VTKMTest::VTKMTest()
{

}

void VTKMTest::CreateVTKMTest()
{

}
