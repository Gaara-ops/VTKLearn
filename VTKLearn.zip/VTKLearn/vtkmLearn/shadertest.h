#ifndef SHADERTEST_H
#define SHADERTEST_H


class ShaderTest
{
public:
    ShaderTest();
    ~ShaderTest();

    void CreateShaderTest();
};

#endif // SHADERTEST_H
